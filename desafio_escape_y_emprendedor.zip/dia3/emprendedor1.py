
p = float(input("Ingrese precio de suscripcion: \n"))
u = float(input("Ingrese numero de usuarios: \n"))
gt = float(input("Ingrese gastos totales: \n"))

#utilidades = p * u - gt

utilidades = p * u - gt

print("La utilidad es: ", round(utilidades, ), "Clp")

